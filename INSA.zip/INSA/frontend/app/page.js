'use client';
import { useState, useEffect, useRef } from 'react';

const THEMES = {
  slate: {
    name: 'Dark Slate (Default)',
    bg: 'bg-slate-950',
    card: 'bg-slate-900 border-slate-800',
    sidebar: 'bg-slate-950 border-slate-800',
    chatBg: 'bg-slate-900',
    inputBg: 'bg-slate-950 border-slate-800',
    text: 'text-white',
    accent: 'bg-cyan-600 hover:bg-cyan-500 text-white',
    accentText: 'text-cyan-400',
    bubbleSelf: 'bg-cyan-600 text-white',
    bubbleOther: 'bg-slate-800 text-slate-200',
  },
  midnight: {
    name: 'Midnight Blue',
    bg: 'bg-blue-950',
    card: 'bg-blue-900/80 border-blue-800',
    sidebar: 'bg-blue-950 border-blue-800',
    chatBg: 'bg-blue-900/40',
    inputBg: 'bg-blue-950 border-blue-800',
    text: 'text-white',
    accent: 'bg-indigo-600 hover:bg-indigo-500 text-white',
    accentText: 'text-indigo-400',
    bubbleSelf: 'bg-indigo-600 text-white',
    bubbleOther: 'bg-blue-800 text-blue-100',
  },
};

const arrayBufferToBase64 = (buffer) => {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
};

const base64ToUint8Array = (base64) => {
  const binaryString = window.atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
};

// IndexedDB Storage
const openDatabase = () => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('AmphyDB', 1);
    request.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('chats')) db.createObjectStore('chats', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('contacts')) db.createObjectStore('contacts', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('keys')) db.createObjectStore('keys', { keyPath: 'username' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

const saveLocalHistory = async (currentUser, contact, messages) => {
  try {
    const db = await openDatabase();
    const tx = db.transaction('chats', 'readwrite');
    await tx.objectStore('chats').put({ id: `${currentUser}_${contact}`, messages });
  } catch {
    // Ignore storage errors
  }
};

const loadLocalHistory = async (currentUser, contact) => {
  try {
    const db = await openDatabase();
    const tx = db.transaction('chats', 'readonly');
    return new Promise((resolve) => {
      const req = tx.objectStore('chats').get(`${currentUser}_${contact}`);
      req.onsuccess = () => resolve(req.result ? req.result.messages : []);
      req.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
};

const saveLocalContacts = async (currentUser, contactsList) => {
  try {
    const db = await openDatabase();
    const tx = db.transaction('contacts', 'readwrite');
    await tx.objectStore('contacts').put({ id: currentUser, list: contactsList });
  } catch {
    // Ignore storage errors
  }
};

const loadLocalContacts = async (currentUser) => {
  try {
    const db = await openDatabase();
    const tx = db.transaction('contacts', 'readonly');
    return new Promise((resolve) => {
      const req = tx.objectStore('contacts').get(currentUser);
      req.onsuccess = () => resolve(req.result ? req.result.list : []);
      req.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
};

const saveLocalKeys = async (username, keyPair) => {
  try {
    const exportedPrivate = await window.crypto.subtle.exportKey('pkcs8', keyPair.privateKey);
    const exportedPublic = await window.crypto.subtle.exportKey('spki', keyPair.publicKey);
    const db = await openDatabase();
    const tx = db.transaction('keys', 'readwrite');
    await tx.objectStore('keys').put({
      username,
      privateKey: arrayBufferToBase64(exportedPrivate),
      publicKey: arrayBufferToBase64(exportedPublic),
    });
  } catch {
    // Ignore storage errors
  }
};

const loadLocalKeys = async (username) => {
  try {
    const db = await openDatabase();
    const tx = db.transaction('keys', 'readonly');
    return new Promise((resolve) => {
      const req = tx.objectStore('keys').get(username);
      req.onsuccess = async () => {
        if (!req.result) resolve(null);
        else {
          const privateDer = base64ToUint8Array(req.result.privateKey);
          const publicDer = base64ToUint8Array(req.result.publicKey);

          const privateKey = await window.crypto.subtle.importKey(
            'pkcs8', privateDer, { name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveKey', 'deriveBits']
          );
          const publicKey = await window.crypto.subtle.importKey(
            'spki', publicDer, { name: 'ECDH', namedCurve: 'P-256' }, true, []
          );
          resolve({ privateKey, publicKey, publicKeyBase64: req.result.publicKey });
        }
      };
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
};

export default function ChatApp() {
  const [authMode, setAuthMode] = useState('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [suggestedPassword, setSuggestedPassword] = useState('');
  const [isRegistered, setIsRegistered] = useState(false);
  const [status, setStatus] = useState('Disconnected');
  const [authError, setAuthError] = useState('');

  const [showSidebar, setShowSidebar] = useState(true);
  const [sidebarTab, setSidebarTab] = useState('chats');
  const [currentTheme, setCurrentTheme] = useState('slate');

  const [activeContact, setActiveContact] = useState('');
  const [newContactInput, setNewContactInput] = useState('');
  const [contacts, setContacts] = useState([]);
  const [conversations, setConversations] = useState({});
  const [message, setMessage] = useState('');

  // Call & Side-Channel Scanner State
  const [callState, setCallState] = useState('idle');
  const [callerName, setCallerName] = useState('');
  const [scannerActive, setScannerActive] = useState(false);
  const [emanationLevel, setEmanationLevel] = useState(0);
  const [leakWarning, setLeakWarning] = useState(false);

  const keyPairRef = useRef(null);
  const wsRef = useRef(null);
  const peerConnectionRef = useRef(null);
  const localAudioRef = useRef(null);
  const remoteAudioRef = useRef(null);
  const audioContextRef = useRef(null);
  const analyzerRef = useRef(null);

  const theme = THEMES[currentTheme] || THEMES.slate;

  useEffect(() => {
    if (isRegistered && username && activeContact) {
      loadLocalHistory(username, activeContact).then((history) => {
        setConversations((prev) => ({ ...prev, [activeContact]: history }));
      });
    }
  }, [activeContact, isRegistered, username]);

  const getOrGenerateKeys = async (user) => {
    const existing = await loadLocalKeys(user);
    if (existing) {
      keyPairRef.current = { privateKey: existing.privateKey, publicKey: existing.publicKey };
      return existing.publicKeyBase64;
    }

    const keyPair = await window.crypto.subtle.generateKey(
      { name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveKey', 'deriveBits']
    );
    keyPairRef.current = keyPair;
    await saveLocalKeys(user, keyPair);

    const exportedKey = await window.crypto.subtle.exportKey('spki', keyPair.publicKey);
    return arrayBufferToBase64(exportedKey);
  };

  const handleAuth = async () => {
    setAuthError('');
    setSuggestedPassword('');

    if (!username.trim() || !password.trim()) {
      setAuthError('Please enter both username and password.');
      return;
    }

    const user = username.trim();
    try {
      const publicKeyBase64 = await getOrGenerateKeys(user);
      const endpoint = authMode === 'signup' ? '/api/register' : '/api/login';

      const res = await fetch(`http://127.0.0.1:8000${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: user, password: password.trim(), public_key: publicKeyBase64 }),
      });

      const data = await res.json();
      if (data.status === 'success') {
        setIsRegistered(true);
        const savedContacts = await loadLocalContacts(user);
        setContacts(savedContacts);
        if (savedContacts.length > 0) setActiveContact(savedContacts[0]);
        connectWebSocket(user);
      } else {
        let msg = data.message;
        if (data.details) {
          msg += '\n• ' + data.details.join('\n• ');
        }
        if (data.suggested_password) {
          setSuggestedPassword(data.suggested_password);
        }
        setAuthError(msg);
      }
    } catch {
      setAuthError('Unable to connect to Amphy server.');
    }
  };

  const connectWebSocket = (user) => {
    const ws = new WebSocket(`ws://127.0.0.1:8001/${user}`);

    ws.onopen = () => setStatus('Connected (Amphy E2EE)');
    ws.onclose = () => setStatus('Disconnected');
    ws.onerror = () => setStatus('Connection Error');

    ws.onmessage = async (event) => {
      const data = JSON.parse(event.data);

      if (data.type === 'message') {
        const sender = data.sender;
        const decryptedText = await decryptMessage(sender, data.payload);

        setContacts((prev) => {
          const updated = prev.includes(sender) ? prev : [...prev, sender];
          saveLocalContacts(user, updated);
          return updated;
        });

        if (!activeContact) setActiveContact(sender);

        const currentMsgs = await loadLocalHistory(user, sender);
        const updatedMsgs = [
          ...currentMsgs,
          { sender, text: decryptedText, timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
        ];

        await saveLocalHistory(user, sender, updatedMsgs);
        setConversations((prev) => ({ ...prev, [sender]: updatedMsgs }));
      } else if (data.type === 'call-offer') {
        setCallerName(data.sender);
        setCallState('incoming');
        peerConnectionRef.current = createPeerConnection(data.sender);
        await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(data.signalData));
      } else if (data.type === 'call-answer') {
        if (peerConnectionRef.current) {
          await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(data.signalData));
          setCallState('connected');
        }
      } else if (data.type === 'ice-candidate') {
        if (peerConnectionRef.current && data.signalData) {
          await peerConnectionRef.current.addIceCandidate(new RTCIceCandidate(data.signalData));
        }
      } else if (data.type === 'end-call') {
        terminateCall();
      }
    };

    wsRef.current = ws;
  };

  // WebRTC Call & Acoustic Side-Channel Scanner
  const startAudioScan = (stream) => {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    const analyzer = ctx.createAnalyser();
    const source = ctx.createMediaStreamSource(stream);

    analyzer.fftSize = 256;
    source.connect(analyzer);

    audioContextRef.current = ctx;
    analyzerRef.current = analyzer;
    setScannerActive(true);

    const dataArray = new Uint8Array(analyzer.frequencyBinCount);
    const scanInterval = setInterval(() => {
      if (!analyzerRef.current) {
        clearInterval(scanInterval);
        return;
      }
      analyzerRef.current.getByteFrequencyData(dataArray);

      let sum = 0;
      for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
      const avg = Math.round(sum / dataArray.length);

      setEmanationLevel(avg);
      setLeakWarning(avg > 80);
    }, 200);
  };

  const createPeerConnection = (targetUser) => {
    const pc = new RTCPeerConnection({
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
    });

    pc.onicecandidate = (event) => {
      if (event.candidate && wsRef.current) {
        wsRef.current.send(JSON.stringify({
          type: 'ice-candidate',
          recipient: targetUser,
          signalData: event.candidate,
        }));
      }
    };

    pc.ontrack = (event) => {
      if (remoteAudioRef.current) {
        remoteAudioRef.current.srcObject = event.streams[0];
      }
    };

    return pc;
  };

  const startCall = async () => {
    if (!activeContact) return;
    setCallState('calling');
    setCallerName(activeContact);

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    localAudioRef.current = stream;
    startAudioScan(stream);

    const pc = createPeerConnection(activeContact);
    stream.getTracks().forEach((track) => pc.addTrack(track, stream));
    peerConnectionRef.current = pc;

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);

    wsRef.current.send(JSON.stringify({
      type: 'call-offer',
      recipient: activeContact,
      signalData: offer,
    }));
  };

  const answerCall = async () => {
    setCallState('connected');
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    localAudioRef.current = stream;
    startAudioScan(stream);

    const pc = peerConnectionRef.current;
    stream.getTracks().forEach((track) => pc.addTrack(track, stream));

    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);

    wsRef.current.send(JSON.stringify({
      type: 'call-answer',
      recipient: callerName,
      signalData: answer,
    }));
  };

  const terminateCall = () => {
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }
    if (localAudioRef.current) {
      localAudioRef.current.getTracks().forEach((track) => track.stop());
      localAudioRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    setScannerActive(false);
    setCallState('idle');
  };

  const endCall = () => {
    if (wsRef.current && (activeContact || callerName)) {
      wsRef.current.send(JSON.stringify({
        type: 'end-call',
        recipient: callerName || activeContact,
      }));
    }
    terminateCall();
  };

  const encryptMessage = async (recipientUser, plainText) => {
    const res = await fetch(`http://127.0.0.1:8000/api/get_key/${recipientUser}`);
    const data = await res.json();
    if (data.status !== 'success') throw new Error(`User "${recipientUser}" not found`);

    const binaryDer = base64ToUint8Array(data.public_key);
    const recipientPubKey = await window.crypto.subtle.importKey(
      'spki', binaryDer, { name: 'ECDH', namedCurve: 'P-256' }, false, []
    );

    const sharedKey = await window.crypto.subtle.deriveKey(
      { name: 'ECDH', public: recipientPubKey }, keyPairRef.current.privateKey,
      { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']
    );

    const encoder = new TextEncoder();
    const encodedData = encoder.encode(plainText.normalize('NFC'));
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const ciphertext = await window.crypto.subtle.encrypt({ name: 'AES-GCM', iv }, sharedKey, encodedData);

    return { iv: arrayBufferToBase64(iv), ciphertext: arrayBufferToBase64(ciphertext) };
  };

  const decryptMessage = async (senderUser, payload) => {
    try {
      const res = await fetch(`http://127.0.0.1:8000/api/get_key/${senderUser}`);
      const data = await res.json();

      const binaryDer = base64ToUint8Array(data.public_key);
      const senderPubKey = await window.crypto.subtle.importKey(
        'spki', binaryDer, { name: 'ECDH', namedCurve: 'P-256' }, false, []
      );

      const sharedKey = await window.crypto.subtle.deriveKey(
        { name: 'ECDH', public: senderPubKey }, keyPairRef.current.privateKey,
        { name: 'AES-GCM', length: 256 }, false, ['decrypt']
      );

      const iv = base64ToUint8Array(payload.iv);
      const ciphertext = base64ToUint8Array(payload.ciphertext);
      const decrypted = await window.crypto.subtle.decrypt({ name: 'AES-GCM', iv }, sharedKey, ciphertext);

      return new TextDecoder().decode(decrypted);
    } catch {
      return '[Decryption Failed - Key Mismatch]';
    }
  };

  const sendMessage = async () => {
    if (!message.trim() || !activeContact || !wsRef.current) return;

    try {
      const encryptedPayload = await encryptMessage(activeContact, message);
      wsRef.current.send(JSON.stringify({ recipient: activeContact, payload: encryptedPayload }));

      const newMsg = {
        sender: username,
        text: message.normalize('NFC'),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      const updatedMsgs = [...(conversations[activeContact] || []), newMsg];
      await saveLocalHistory(username, activeContact, updatedMsgs);
      setConversations((prev) => ({ ...prev, [activeContact]: updatedMsgs }));
      setMessage('');
    } catch (err) {
      alert(`Could not send message: ${err.message}`);
    }
  };

  const addContact = async () => {
    const contact = newContactInput.trim();
    if (contact && !contacts.includes(contact)) {
      const updatedContacts = [...contacts, contact];
      setContacts(updatedContacts);
      await saveLocalContacts(username, updatedContacts);
      setActiveContact(contact);
      setNewContactInput('');

      const savedMsgs = await loadLocalHistory(username, contact);
      setConversations((prev) => ({ ...prev, [contact]: savedMsgs }));
    }
  };

  return (
    <main className={`min-h-screen ${theme.bg} ${theme.text} p-4 flex flex-col items-center justify-center transition-colors duration-300`}>
      <audio ref={remoteAudioRef} autoPlay />

      <div className={`max-w-4xl w-full ${theme.card} rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[680px] border transition-colors duration-300`}>
        
        {/* Header */}
        <div className={`flex justify-between items-center p-4 border-b ${theme.sidebar}`}>
          <div className="flex items-center gap-3">
            {isRegistered && (
              <button
                onClick={() => setShowSidebar(!showSidebar)}
                className={`w-9 h-9 rounded-full ${theme.inputBg} border flex items-center justify-center text-xs font-bold transition`}
              >
                {showSidebar ? '◄' : '►'}
              </button>
            )}
            <div>
              <h1 className={`text-xl font-extrabold tracking-wider ${theme.accentText}`}>AMPHY</h1>
              <p className="text-[10px] opacity-70">Secure E2EE Chat & Voice Platform</p>
            </div>
          </div>
          <span className={`text-xs px-2.5 py-1 rounded-full ${isRegistered ? 'bg-green-950 text-green-400 border border-green-800' : 'opacity-50'}`}>
            {status}
          </span>
        </div>

        {!isRegistered ? (
          /* Sign In / Sign Up */
          <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-4 max-w-sm mx-auto w-full">
            <div className="flex gap-1 p-1 bg-black/20 rounded-xl w-full">
              <button
                onClick={() => { setAuthMode('login'); setAuthError(''); setSuggestedPassword(''); }}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition ${authMode === 'login' ? theme.accent : 'opacity-70'}`}
              >
                Sign In
              </button>
              <button
                onClick={() => { setAuthMode('signup'); setAuthError(''); setSuggestedPassword(''); }}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition ${authMode === 'signup' ? theme.accent : 'opacity-70'}`}
              >
                Sign Up
              </button>
            </div>

            {authError && (
              <div className="w-full bg-red-950/80 border border-red-800 text-red-200 text-xs p-3 rounded-lg text-left whitespace-pre-wrap">
                {authError}
              </div>
            )}

            {suggestedPassword && (
              <div className="w-full bg-cyan-950/80 border border-cyan-800 text-cyan-200 text-xs p-3 rounded-lg text-left">
                <p className="font-bold mb-1">Suggested Password:</p>
                <code className="bg-black/40 px-2 py-1 rounded text-cyan-300 select-all block mb-2">{suggestedPassword}</code>
                <button
                  onClick={() => { setPassword(suggestedPassword); setSuggestedPassword(''); }}
                  className="bg-cyan-600 hover:bg-cyan-500 text-white text-[10px] font-bold px-2.5 py-1 rounded"
                >
                  Use Suggested Password
                </button>
              </div>
            )}

            <div className="w-full space-y-3">
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Username..."
                className={`w-full p-3 rounded-lg ${theme.inputBg} border ${theme.text} text-sm focus:outline-none`}
              />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAuth()}
                placeholder="Password..."
                className={`w-full p-3 rounded-lg ${theme.inputBg} border ${theme.text} text-sm focus:outline-none`}
              />
            </div>

            <button onClick={handleAuth} className={`w-full ${theme.accent} font-semibold p-3 rounded-lg text-sm`}>
              {authMode === 'login' ? 'Sign In' : 'Create Account'}
            </button>
          </div>
        ) : (
          /* Main Layout */
          <div className="flex flex-1 overflow-hidden">
            
            {/* Sidebar */}
            {showSidebar && (
              <div className={`w-72 ${theme.sidebar} border-r p-3 flex flex-col`}>
                <div className="flex gap-1 p-1 bg-black/20 rounded-lg mb-3">
                  <button
                    onClick={() => setSidebarTab('chats')}
                    className={`flex-1 py-1.5 text-xs font-semibold rounded-md ${sidebarTab === 'chats' ? theme.accent : 'opacity-70'}`}
                  >
                    Chats
                  </button>
                  <button
                    onClick={() => setSidebarTab('settings')}
                    className={`flex-1 py-1.5 text-xs font-semibold rounded-md ${sidebarTab === 'settings' ? theme.accent : 'opacity-70'}`}
                  >
                    Profile
                  </button>
                </div>

                {sidebarTab === 'chats' ? (
                  <>
                    <div className="mb-3">
                      <div className="flex gap-1">
                        <input
                          type="text"
                          value={newContactInput}
                          onChange={(e) => setNewContactInput(e.target.value)}
                          placeholder="New contact..."
                          className={`w-full p-2 text-xs rounded ${theme.inputBg} border focus:outline-none`}
                        />
                        <button onClick={addContact} className={`${theme.accent} px-3 text-xs font-bold rounded`}>+</button>
                      </div>
                    </div>

                    <div className="flex-1 overflow-y-auto space-y-1">
                      {contacts.map((contact) => (
                        <button
                          key={contact}
                          onClick={() => setActiveContact(contact)}
                          className={`w-full text-left p-2.5 rounded-lg text-sm flex justify-between ${
                            activeContact === contact ? theme.accent : 'hover:bg-white/5 opacity-80'
                          }`}
                        >
                          <span>{contact}</span>
                        </button>
                      ))}
                    </div>
                  </>
                ) : (
                  <div className="flex-1 overflow-y-auto space-y-4">
                    <div className={`p-3 rounded-xl ${theme.inputBg} border`}>
                      <p className="text-sm font-bold">{username}</p>
                      <p className="text-[10px] text-green-400 font-medium">● Side-Channel Defense Active</p>
                    </div>

                    <div>
                      <p className="text-xs font-semibold mb-2">Select Theme</p>
                      <select
                        value={currentTheme}
                        onChange={(e) => setCurrentTheme(e.target.value)}
                        className={`w-full p-2 text-xs rounded ${theme.inputBg} border`}
                      >
                        {Object.keys(THEMES).map((key) => (
                          <option key={key} value={key}>{THEMES[key].name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Main Chat & Call Area */}
            <div className={`flex-1 flex flex-col ${theme.chatBg} p-4`}>
              
              {/* Call Overlay Panel */}
              {callState !== 'idle' && (
                <div className="mb-4 p-4 bg-slate-900 border border-cyan-800 rounded-xl flex items-center justify-between">
                  <div>
                    <p className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                      {callState === 'calling' && `Calling ${callerName}...`}
                      {callState === 'incoming' && `Incoming Call from ${callerName}`}
                      {callState === 'connected' && `Encrypted Call with ${callerName}`}
                    </p>
                    {scannerActive && (
                      <p className={`text-[10px] mt-1 font-mono ${leakWarning ? 'text-red-400' : 'text-green-400'}`}>
                        Emanation Level: {emanationLevel} {leakWarning ? '⚠️ Physical Leak Detected' : '✓ Normal'}
                      </p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    {callState === 'incoming' && (
                      <button onClick={answerCall} className="bg-green-600 hover:bg-green-500 px-4 py-2 text-xs font-bold rounded-lg">
                        Answer
                      </button>
                    )}
                    <button onClick={endCall} className="bg-red-600 hover:bg-red-500 px-4 py-2 text-xs font-bold rounded-lg">
                      End
                    </button>
                  </div>
                </div>
              )}

              {activeContact ? (
                <>
                  <div className="pb-3 mb-3 border-b border-white/10 flex justify-between items-center">
                    <h2 className={`text-sm font-semibold ${theme.accentText}`}>Chatting with {activeContact}</h2>
                    {callState === 'idle' && (
                      <button onClick={startCall} className="bg-green-600 hover:bg-green-500 text-white text-xs px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1">
                        📞 Start Call
                      </button>
                    )}
                  </div>

                  <div className="flex-1 overflow-y-auto space-y-2 pr-1">
                    {(conversations[activeContact] || []).map((msg, index) => (
                      <div key={index} className={`flex flex-col ${msg.sender === username ? 'items-end' : 'items-start'}`}>
                        <div className={`max-w-[75%] p-2.5 rounded-lg text-sm ${msg.sender === username ? theme.bubbleSelf : theme.bubbleOther}`}>
                          <p>{msg.text}</p>
                          <span className="text-[10px] opacity-70 block text-right mt-1">{msg.timestamp}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="flex gap-2 mt-3">
                    <input
                      type="text"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                      placeholder="Send a message..."
                      className={`flex-1 p-3 rounded-lg ${theme.inputBg} border text-sm ${theme.text} focus:outline-none`}
                    />
                    <button onClick={sendMessage} className={`${theme.accent} px-5 py-2 rounded-lg text-sm font-semibold`}>
                      Send
                    </button>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center opacity-50 text-xs">
                  Select a contact or add a new chat from the sidebar
                </div>
              )}
            </div>

          </div>
        )}
      </div>
    </main>
  );
}